// import { useEffect, useState } from "react";
// import { getUsers } from "../auth"; // Asegúrate de importar la función
// import { useAuth } from "../../hooks/useAuth";


// interface User {
//   id: number;
//   name: string;
//   email: string;
//   role: string; // Asegúrate de que el backend devuelva el rol
// }

// const UserList = () => {
//   const { user } = useAuth(); // Obtenemos el usuario autenticado
//   const [users, setUsers] = useState<User[]>([]);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     if (user?.role === "superadmin") { // Solo carga si es superadmin
//       const fetchUsers = async () => {
//         try {
//           const response = await getUsers();
//           setUsers(response);
//         } catch (error) {
//           console.error("Error al obtener usuarios:", error);
//         } finally {
//           setLoading(false);
//         }
//       };
//       fetchUsers();
//     } else {
//       setLoading(false);
//     }
//   }, [user]);

//   return (
//     <div className="p-6">
//       <h2 className="text-2xl font-bold mb-4">Dashboard</h2>

//       {user?.role === "superadmin" ? (
//         <div>
//           <h3 className="text-xl font-semibold mb-3">Lista de Usuarios</h3>
//           {loading ? (
//             <p>Cargando usuarios...</p>
//           ) : (
//             <table className="w-full border-collapse border border-gray-300">
//               <thead>
//                 <tr className="bg-gray-200">
//                   <th className="border border-gray-300 p-2">ID</th>
//                   <th className="border border-gray-300 p-2">Nombre</th>
//                   <th className="border border-gray-300 p-2">Correo</th>
//                   <th className="border border-gray-300 p-2">Rol</th>
//                 </tr>
//               </thead>
//               <tbody>
//                 {users.map((user) => (
//                   <tr key={user.id} className="hover:bg-gray-100">
//                     <td className="border border-gray-300 p-2 text-center">{user.id}</td>
//                     <td className="border border-gray-300 p-2">{user.name}</td>
//                     <td className="border border-gray-300 p-2">{user.email}</td>
//                     <td className="border border-gray-300 p-2">{user.role}</td>
//                   </tr>
//                 ))}
//               </tbody>
//             </table>
//           )}
//         </div>
//       ) : (
//         <p>No tienes permisos para ver esta información.</p>
//       )}
//     </div>
//   );
// };

// export default UserList;

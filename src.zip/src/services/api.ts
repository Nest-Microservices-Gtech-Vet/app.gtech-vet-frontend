import axios from 'axios';

// 🔹 Crear una instancia de Axios con la base URL de tu API
const api = axios.create({
  baseURL: 'http://localhost:3000/api', // Cambia esto según tu backend
  headers: {
    'Content-Type': 'application/json',
  },
});

// 🔹 Interceptor para agregar el Token a cada petición
api.interceptors.request.use((config) => {
    const token = localStorage.getItem('accessToken');
    
    if (token) {
      config.headers = {
        ...config.headers, // Mantener otros headers existentes
        Authorization: `Bearer ${token}`
      };
    }
  
    return config;
  }, (error) => {
    return Promise.reject(error);
  });
  

export default api;
